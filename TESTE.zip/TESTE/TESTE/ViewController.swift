//
//  ViewController.swift
//  TESTE
//
//  Created by COTEMIG on 31/05/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var buttone: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

